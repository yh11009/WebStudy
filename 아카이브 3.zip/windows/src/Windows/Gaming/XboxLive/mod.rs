#[cfg(feature = "Gaming_XboxLive_Storage")]
pub mod Storage;
#[cfg(feature = "implement")]
::core::include!("impl.rs");
