#[cfg(feature = "Security_Authorization_AppCapabilityAccess")]
pub mod AppCapabilityAccess;
#[cfg(feature = "implement")]
::core::include!("impl.rs");
