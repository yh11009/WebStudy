#[rustversion::since(stable)]
struct S;

#[rustversion::any(since(stable))]
struct S;

fn main() {}
