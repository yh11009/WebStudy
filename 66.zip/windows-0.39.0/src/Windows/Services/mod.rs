#[cfg(feature = "Services_Cortana")]
pub mod Cortana;
#[cfg(feature = "Services_Maps")]
pub mod Maps;
#[cfg(feature = "Services_Store")]
pub mod Store;
#[cfg(feature = "Services_TargetedContent")]
pub mod TargetedContent;
#[cfg(feature = "implement")]
::core::include!("impl.rs");
