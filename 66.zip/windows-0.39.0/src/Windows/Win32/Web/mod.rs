#[cfg(feature = "Win32_Web_MsHtml")]
pub mod MsHtml;
#[cfg(feature = "implement")]
::core::include!("impl.rs");
