#[doc = "*Required features: `\"Win32_Graphics_Hlsl\"`*"]
pub const D3DCOMPILER_DLL: &str = "d3dcompiler_47.dll";
#[doc = "*Required features: `\"Win32_Graphics_Hlsl\"`*"]
pub const D3DCOMPILE_OPTIMIZATION_LEVEL2: u32 = 49152u32;
#[doc = "*Required features: `\"Win32_Graphics_Hlsl\"`*"]
pub const D3D_COMPILE_STANDARD_FILE_INCLUDE: u32 = 1u32;
