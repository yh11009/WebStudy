pub type IWICImageEncoder = *mut ::core::ffi::c_void;
pub type IWICImagingFactory2 = *mut ::core::ffi::c_void;
