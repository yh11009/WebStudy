pub type IChannelCredentials = *mut ::core::ffi::c_void;
