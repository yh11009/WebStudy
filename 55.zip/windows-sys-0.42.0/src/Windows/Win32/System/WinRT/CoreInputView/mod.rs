pub type ICoreFrameworkInputViewInterop = *mut ::core::ffi::c_void;
