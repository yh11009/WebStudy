pub type ISoftwareBitmapNative = *mut ::core::ffi::c_void;
pub type ISoftwareBitmapNativeFactory = *mut ::core::ffi::c_void;
pub const CLSID_SoftwareBitmapNativeFactory: ::windows_sys::core::GUID = ::windows_sys::core::GUID { data1: 2229687953, data2: 34306, data3: 19076, data4: [190, 70, 112, 139, 233, 205, 75, 116] };
