pub type IGraphicsCaptureItemInterop = *mut ::core::ffi::c_void;
