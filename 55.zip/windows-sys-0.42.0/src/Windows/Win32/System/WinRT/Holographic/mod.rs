pub type IHolographicCameraInterop = *mut ::core::ffi::c_void;
pub type IHolographicCameraRenderingParametersInterop = *mut ::core::ffi::c_void;
pub type IHolographicQuadLayerInterop = *mut ::core::ffi::c_void;
pub type IHolographicQuadLayerUpdateParametersInterop = *mut ::core::ffi::c_void;
