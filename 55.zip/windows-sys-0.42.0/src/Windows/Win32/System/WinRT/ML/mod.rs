pub type ILearningModelDeviceFactoryNative = *mut ::core::ffi::c_void;
pub type ILearningModelOperatorProviderNative = *mut ::core::ffi::c_void;
pub type ILearningModelSessionOptionsNative = *mut ::core::ffi::c_void;
pub type ITensorNative = *mut ::core::ffi::c_void;
pub type ITensorStaticsNative = *mut ::core::ffi::c_void;
