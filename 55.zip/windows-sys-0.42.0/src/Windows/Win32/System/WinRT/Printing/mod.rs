pub type IPrintManagerInterop = *mut ::core::ffi::c_void;
pub type IPrintWorkflowConfigurationNative = *mut ::core::ffi::c_void;
pub type IPrintWorkflowObjectModelSourceFileContentNative = *mut ::core::ffi::c_void;
pub type IPrintWorkflowXpsObjectModelTargetPackageNative = *mut ::core::ffi::c_void;
pub type IPrintWorkflowXpsReceiver = *mut ::core::ffi::c_void;
pub type IPrintWorkflowXpsReceiver2 = *mut ::core::ffi::c_void;
pub type IPrinting3DManagerInterop = *mut ::core::ffi::c_void;
