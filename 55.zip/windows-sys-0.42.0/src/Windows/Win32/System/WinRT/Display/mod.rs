pub type IDisplayDeviceInterop = *mut ::core::ffi::c_void;
pub type IDisplayPathInterop = *mut ::core::ffi::c_void;
