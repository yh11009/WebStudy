pub type IIsolatedEnvironmentInterop = *mut ::core::ffi::c_void;
