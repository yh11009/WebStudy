pub type IWindowsDevicesAllJoynBusAttachmentFactoryInterop = *mut ::core::ffi::c_void;
pub type IWindowsDevicesAllJoynBusAttachmentInterop = *mut ::core::ffi::c_void;
pub type IWindowsDevicesAllJoynBusObjectFactoryInterop = *mut ::core::ffi::c_void;
pub type IWindowsDevicesAllJoynBusObjectInterop = *mut ::core::ffi::c_void;
