pub type IRadialControllerConfigurationInterop = *mut ::core::ffi::c_void;
pub type IRadialControllerIndependentInputSourceInterop = *mut ::core::ffi::c_void;
pub type IRadialControllerInterop = *mut ::core::ffi::c_void;
