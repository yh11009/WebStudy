// Take a look at the license at the top of the repository in the LICENSE file.

pub type AttributeSet = glib::translate::SList;
