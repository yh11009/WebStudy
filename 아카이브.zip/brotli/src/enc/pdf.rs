
//TODO: replace with builtin SIMD type

#[derive(Copy, Clone, Default, Debug)]
pub struct PDF([i16;16]);


