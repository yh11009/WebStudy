# core-graphics-rs

[![Build Status](https://travis-ci.com/servo/core-graphics-rs.svg?branch=master)](https://travis-ci.com/servo/core-graphics-rs)
