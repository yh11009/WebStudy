# [Unreleased]

# [0.2.8] - 2021-10-27

- Optionally support no_std
  [#31](https://github.com/lambda-fairy/rust-errno/pull/31)

[Unreleased]: https://github.com/lambda-fairy/rust-errno/compare/v0.2.8...HEAD
[0.2.8]: https://github.com/lambda-fairy/rust-errno/compare/v0.2.7...v0.2.8
