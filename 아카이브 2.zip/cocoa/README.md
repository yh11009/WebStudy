Cocoa-rs
--------

This crate provides Rust bindings to Cocoa for macOS. It's dual-licensed MIT /
Apache 2.0. If you'd like to help improve cocoa-rs, check out [the Servo
contributing guide](https://github.com/servo/servo/blob/master/CONTRIBUTING.md)! 
