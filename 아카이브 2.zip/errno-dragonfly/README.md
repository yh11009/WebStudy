# errno-dragonfly-rs

Exposing `errno` functionality to stable Rust on DragonFly BSD.
